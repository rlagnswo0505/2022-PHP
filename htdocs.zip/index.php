<?php
require_once 'application/libs/Config.php'; //상수
require_once 'application/libs/Autoload.php'; //파일, require 해주는 친구
new application\libs\Application();
