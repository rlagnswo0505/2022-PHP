<?php
define('_ROOT', $_SERVER['DOCUMENT_ROOT']);
define('_DBTYPE', 'mysql'); //mysql, mariadb 등
define('_HOST', 'localhost'); //DB주소
define('_DBNAME', 'board_login'); //DB명
define('_DBUSER', 'root'); //아이디
define('_DBPASSWORD', '506greendg@'); //비번
define('_CHARSET', 'utf8');
define('_VIEW', 'application/views/');

define('_HEADER', 'header');
define('_MAIN', 'main');
define('_FOOTER', 'footer');

define('_CSS', 'css');
define('_JS', 'js');
