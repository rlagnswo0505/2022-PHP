<!DOCTYPE html>
<html lang="en">
<?php include_once "application/views/template/head.php"; ?>

<body>
    <div class="container">
        <header><?php include_once $this->header;?></header>
        <main><?php include_once $this->main;?></main>
        <footer><?php include_once $this->footer;?></footer>
    </div>
</body>
</html>