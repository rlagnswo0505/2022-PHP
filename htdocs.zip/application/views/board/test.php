<?php
print '아무거나';
print '아무거나';
